criaCartao(
    'Astronomia',
    'Quais são os 8 corpos celestes?',
    'Júpiter, Marte, Mercúrio, Netuno, Saturno, Terra, Urano, Vênus',
)

criaCartao(
    'Biologia',
    'Quais são os tipos de Biologia?',
    'Existem três ramos principais reconhecidos da biologia, que são: botânica, zoologia, microbiologia',
)

criaCartao(
    'Geografia',
    'Qual a capital do Amazonas?',
    'Manaus'
)

criaCartao(
    'Inglês',
    'Como se diz Abacaxi em inglês?',
    'Pineapple'
)

criaCartao(
    'Matemática',
    'Como se divide a matemática?',
    'A matemática é subdividida em aritmética, álgebra, trigonometria e geometria'
)

criaCartao(
    'Química',
    'Quem é o criador da química?',
    'Antoine Lavoisier'
)

criaCartao(
    'Física',
    'O que é p na Física?',
    'A potência'
)

